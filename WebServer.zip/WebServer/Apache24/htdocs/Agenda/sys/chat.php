<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="css/chat.css">
    <title>Chat</title>
	<script src="js/script.js" defer>

    </script>
	
</head>
<body>
<header>
    <button id="btn-menu"><i class='bx bx-menu'></i></button>
        <h1>Página de Chat</h1>
    </header>

    <div style="clear:both;"></div>

   <div class="container"> 
    <nav class="nav-link">
        <ul>
            <li><a href="agenda.php">Agenda</a></li>
            <li><a href="pagPerfil.php">Seu Perfil</a></li>
            <li><a href="cadastroContato.php">Cadastrar Contatos</a></li>
            <li><a href="logoff.php">Sair</a></li>
        </ul>
    </nav>

    <div id="chat">
	
	</div>

	<form action="chat.php" method="post">
        <label for="name">Nome:</label>
        <input type="text" id="name" name="name" required>  
        <label for="msg">Mensagem:</label>
        <input type="text" id="msg" name="msg" required> 
		<button id="button-env" type="submit" name="Enviar">Enviar</button>
	</form>
    </div>
</body>
</html>

<?php
extract($_POST);

if (isset($_POST["Enviar"])) {
    include_once("class/connect.php");
    $obj = new connect();
    $resultado = $obj->conectarBanco();

    $nome = htmlspecialchars($_POST['name']);
    $mensagem = htmlspecialchars($_POST['msg']);
    $sql = "INSERT INTO Chat (nome, mensagem) VALUES (:nome, :mensagem)";

    $query = $resultado->prepare($sql);
    $query->bindParam(':nome', $nome);
    $query->bindParam(':mensagem', $mensagem);

    if ($query->execute()) {
        header('Location: chat.php');
        exit();
    } else {
        echo "Erro ao enviar mensagem.";
    }
}
?>