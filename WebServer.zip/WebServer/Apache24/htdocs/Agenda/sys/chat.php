<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="css/chat.css">
    <title>Chat</title>
	<script src="js/script.js" defer>

    </script>
	
</head>
<body>
<header>
    <button id="btn-menu"><i class='menu bx bx-menu'></i></button>
        <h1>Página de Chat</h1>
    </header>

    <div style="clear:both;"></div>

   <div class="container"> 
    <nav class="nav-link">
        <ul>
            <li><a href="agenda.php">Agenda</a></li>
            <li><a href="pagPerfil.php">Seu Perfil</a></li>
            <li><a href="cadastroContato.php">Cadastrar Contatos</a></li>
            <li><a href="tarefas.php">Suas Tarefas</a></li>
            <li><a href="logoff.php">Sair</a></li>
        </ul>
    </nav>

    <div id="chat">
	
	</div>

	<form action="chat.php" method="post">
        <label for="name">Nome:</label>
        <input type="text" id="name" name="name" required>  
        <label for="msg">Mensagem:</label>
        <input type="text" id="msg" name="msg" required> 
		<button id="button-env" type="submit" name="Enviar">Enviar</button>
	</form>
    </div>
</body>
</html>

<?php
extract($_POST);

if (isset($_POST["Enviar"])) {
    include_once("class/connect.php");
    $obj = new connect();
    $resultado = $obj->conectarBanco();

    $nome = htmlspecialchars($_POST['name']);
    $mensagem = htmlspecialchars($_POST['msg']);

    // Lista de palavras proibidas
    $palavrasProibidas = ['vai toma no cu', 'diabo', 'puta']; // Substitua por palavras reais

    // Função para verificar e substituir palavras proibidas
    function filtrarMensagem($mensagem, $palavrasProibidas) {
        foreach ($palavrasProibidas as $palavra) {
            // Substitui a palavra proibida por asteriscos
            $mensagem = str_ireplace($palavra, str_repeat('*', strlen($palavra)), $mensagem);
        }
        return $mensagem;
    }

    // Verificar se a mensagem contém palavras proibidas e filtrar
    $mensagemFiltrada = filtrarMensagem($mensagem, $palavrasProibidas);

    // Inserir a mensagem filtrada no banco de dados
    $sql = "INSERT INTO Chat (nome, mensagem) VALUES (:nome, :mensagem)";
    $query = $resultado->prepare($sql);
    $query->bindParam(':nome', $nome);
    $query->bindParam(':mensagem', $mensagemFiltrada);

    if ($query->execute()) {
        header('Location: chat.php');
        exit();
    } else {
        echo "Erro ao enviar mensagem.";
    }
}
?>