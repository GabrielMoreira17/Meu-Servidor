<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat</title>
</head>
<body>
    <script scr="js/script.js"></script>

    <div id="chat" style=""></div>

<?php
    include_once("class/connect.php");
    $obj = new connect();
    $resultado = $obj->conectarBanco();

    $sql = "SELECT * FROM Chat";

    $query = $resultado->prepare($sql);
    $indice = 0;

    if($query->execute())
    {
        while($linha = $query->fetch(PDO::FETCH_ASSOC))
        {
            $linhas[$indice] = $linha;
            echo "<h3>".$linhas[$indice]['nome'];
        }
    }
?>
</body>
</html>