<?php
    session_name('sessaoLogin');
    session_start();
    
    include_once("class/connect.php");
    $obj = new connect();
    $resultado = $obj->conectarBanco();

    $sql = "SELECT usuario, email, imagem FROM Users WHERE id = :id";
    
    $query = $resultado->prepare($sql);
    $query->bindParam(':id', $_SESSION['id']);
    if($query->execute())
{
    while($user = $query->fetch(PDO::FETCH_ASSOC))
    {
        $users[0] = $user;
    }
}
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="css/perfil.css">
    <title>Página de Perfil da Agenda</title>
    <script src="js/script.js" defer></script>
</head>
<body>


    <header>
        <button id="btn-menu"><i class='menu bx bx-menu'></i></button>
        <h1>Seu Perfil</h1>
        <a href="agenda.php"><button id="btn-agenda">Agenda</button></a>
    </header>

    <div class="container">
        <h1>Informações de <?php echo $users[0]['email']; ?></h1>
        <i class='perfil bx bxs-user'></i>
        <form action="pagPerfil.php">   
            <input id="meuInputNome" type="text" placeholder="Nome Usuário" readonly value="<?= $users[0]['email'] ?>">
            <input id="meuInputEmail" type="text" placeholder="Email" readonly value="<?= $users[0]['email'] ?>">
            <input id="meuInputTelefone" type="text" placeholder="Telefone" readonly>
            <input id="meuInputSenha" type="text" placeholder="Senha" readonly>
            <input id="meuInputImagem" type="file" placeholder="Imagem de Perfil" readonly>
            <button type="button" id="btn-edita">Editar Informações</button>
        </form>
    </div>

    <script>
        document.getElementById('btn-edita').addEventListener('click', function() {
            const inputs = [
                document.getElementById('meuInputNome'),
                document.getElementById('meuInputEmail'),
                document.getElementById('meuInputTelefone'),
                document.getElementById('meuInputSenha'),
                document.getElementById('meuInputImagem')
            ];

            inputs.forEach(input => {
                input.readOnly = !input.readOnly; // Alterna o estado readonly
            });

            this.textContent = inputs[0].readOnly ? 'Editar Informações' : 'Salvar Informações'; // Atualiza o texto do botão
        });
    </script>
</body>
</html>
