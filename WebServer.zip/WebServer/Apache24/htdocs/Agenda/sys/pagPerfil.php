<?php
session_name('sessaoLogin');
session_start();

include_once("class/connect.php");
$obj = new connect();
$resultado = $obj->conectarBanco();

$sql = "SELECT nome, email, passwd, imagem FROM Users WHERE id = :id";
$query = $resultado->prepare($sql);
$query->bindParam(':id', $_SESSION['id']);
$query->execute();
$user = $query->fetch(PDO::FETCH_ASSOC);

if (isset($_POST['update_perfil'])) {
    $nomeUsuario = $_POST['nome'];
    $email = $_POST['email'];
    
    if (!empty($_FILES['imagem']['name'])) {
        $imagem = $_FILES['imagem']['name'];
        $imagemTemp = $_FILES['imagem']['tmp_name'];
        $uploadDir = 'sys/imgs_perfil/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        $uploadFile = $uploadDir . basename($imagem);

        if (move_uploaded_file($imagemTemp, $uploadFile)) {
        } else {
            echo "<script>alert('Erro ao fazer upload da imagem.');</script>";
        }
    } else {
        $imagem = $user['imagem'];
    }

    $sqlUpdate = "UPDATE Users SET nome = :nome, email = :email, imagem = :imagem WHERE id = :id";
    $queryUpdate = $resultado->prepare($sqlUpdate);
    $queryUpdate->bindParam(':nome', $nomeUsuario);
    $queryUpdate->bindParam(':email', $email);
    $queryUpdate->bindParam(':imagem', $imagem);
    $queryUpdate->bindParam(':id', $_SESSION['id']);
    
    if ($queryUpdate->execute()) {
        echo "<script>alert('Informações atualizadas com sucesso!');</script>";
    } else {
        echo "<script>alert('Erro ao atualizar as informações.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="css/perfil.css">
    <title>Página de Perfil da Agenda</title>
    <script src="js/script.js" defer></script>
</head>
<body>

    <header>
        <button id="btn-menu"><i class='menu bx bx-menu'></i></button>
        <h1>Seu Perfil</h1>
    </header>

    <nav class="nav-link">
        <ul>
            <li><a href="agenda.php">Agenda</a></li>
            <li><a href="tarefas.php">Suas Tarefas</a></li>
            <li><a href="cadastroContato.php">Cadastrar Contatos</a></li>
            <li><a href="logoff.php">Sair</a></li>
        </ul>
    </nav>

    <div class="container">
        <div class="container-info">
            <h1>Informações de <?php echo $user['email']; ?></h1>

            <?php if (!empty($user['imagem'])): ?>
                <img src="sys/imgs_perfil/<?php echo $user['imagem']; ?>" alt="Imagem de Perfil" class="perfil-img">
            <?php else: ?>
                <i class='perfil bx bxs-user'></i>
            <?php endif; ?>

            <form action="pagPerfil.php" method="POST" enctype="multipart/form-data">
                <input id="meuInputNome" name="nome" type="text" placeholder="Nome Usuário" value="<?= $user['nome'] ?>">
                <input id="meuInputEmail" name="email" type="text" placeholder="Email" value="<?= $user['email'] ?>">
                <input id="meuInputImagem" name="imagem" type="file" placeholder="Imagem de Perfil">
                <button type="submit" name="update_perfil" id="btn-confirma">Confirmar Alteração</button>
            </form>
        </div>
    </div>

</body>
</html>
