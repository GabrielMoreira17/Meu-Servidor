<?php
    session_name('sessaoLogin');
    session_start();
    
    include_once("class/connect.php");
    $obj = new connect();
    $resultado = $obj->conectarBanco();

    $sql = "SELECT nome, email, passwd, imagem FROM Users WHERE id = :id";
    
    $query = $resultado->prepare($sql);
    $query->bindParam(':id', $_SESSION['id']);
    if($query->execute())
{
    while($user = $query->fetch(PDO::FETCH_ASSOC))
    {
        $users[0] = $user;
    }
}
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="css/perfil.css">
    <title>Página de Perfil da Agenda</title>
    <script src="js/script.js" defer></script>
</head>
<body>

    <header>
        <button id="btn-menu"><i class='menu bx bx-menu'></i></button>
        <h1>Seu Perfil</h1>


    </header>

    <div class="container">

        <nav class="nav-link">
            <ul>
                <li><a href="agenda.php">Agenda</a></li>
                <li><a href="tarefas.php">Suas Tarefas</a></li>
                <li><a href="cadastroContato.php">Cadastrar Contatos</a></li>
                <li><a href="logoff.php">Sair</a></li>
            </ul>
        </nav>

        <div class="container-info">
            <h1>Informações de <?php echo $users[0]['email']; ?></h1>
            <i class='perfil bx bxs-user'></i>
            <form action="pagPerfil.php">
                <input id="meuInputNome" type="text" placeholder="Nome Usuário" readonly value="<?= $users[0]['nome'] ?>">
                <input id="meuInputEmail" type="text" placeholder="Email" readonly value="<?= $users[0]['email'] ?>">
                <input id="meuInputImagem" type="file" placeholder="Imagem de Perfil" readonly>
                <button type="button" id="btn-edita">Editar Informações</button>
            </form>
        </div>
    </div>

<script>
    document.getElementById('btn-edita').addEventListener('click', function() {
        const inputs = 
        [
            document.getElementById('meuInputNome'),
            document.getElementById('meuInputEmail'),
            document.getElementById('meuInputTelefone'),
            document.getElementById('meuInputSenha'),
            document.getElementById('meuInputImagem')
        ];

            inputs.forEach(input => {
                input.readOnly = !input.readOnly; // Alterna o estado readonly
            });

            this.textContent = inputs[0].readOnly ? 'Editar Informações' : 'Salvar Informações'; // Atualiza o texto do botão
    });
</script>
</body>
</html>
