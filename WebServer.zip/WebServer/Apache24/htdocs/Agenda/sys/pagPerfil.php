<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="css/perfil.css">
    <title>Página de Perfil da Agenda</title>
</head>
<body>
    <header>
        <button id="btn-menu"><i class='menu bx bx-menu'></i></button>
        <h1>Seu Perfil</h1>
        <a href="agenda.php"><button id="btn-agenda">Agenda</button></a>
    </header>

    <div class="container">
    <h1>Informações</h1>
    <i class='perfil bx bxs-user'></i>
        <form action="pagPerfil.php">            
            <input readonly type="text" placeholder="Nome Usuário">
            <input readonly type="text" placeholder="Email">
            <input readonly type="text" placeholder="telefone">
            <button id="btn-edita">Editar Informações</button>
        </form>
    </div>
</body>
</html>