function ajax() {
    var req = new XMLHttpRequest();
    req.onreadystatechange = function() {
        if (req.readyState == 4 && req.status == 200) {
            document.getElementById('chat').innerHTML = req.responseText;
        }
    };
    req.open('GET', 'chatRefresh.php', true);
    req.send(); // Certifique-se de enviar a requisição
}

// Chama a função ao carregar a página
window.onload = ajax;

// Atualiza a cada segundo
setInterval(ajax, 1000);
