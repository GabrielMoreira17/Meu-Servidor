<?php
    session_name('sessaoLogin');
    session_start();

    if($_SESSION['agenda'] == FALSE)
    {
        session_destroy();
        header("location: login.php");
    }
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="css/cadastroContato.css">
    <script src="js/script.js" defer></script>
    <title>Cadastro de Contato</title>
</head>
<body>

    <header>
        <h1>Cadastro de Contatos</h1>
        <button id="btn-menu"><i class='menu bx bx-menu'></i></button>
    </header>

    <nav class="nav-link">
            <ul>
                <li><a href="agenda.php">Agenda</a></li>
                <li><a href="chat.php">Chat</a></li>
                <li><a href="tarefas.php">Suas Tarefas</a></li>
                <li><a href="pagPerfil.php">Seu Perfil</a></li>
            </ul>
        </nav>

    <div class="forms-cadastro">
        <form action="cadastroContato.php" method="post" enctype="multipart/form-data">
            <table>
                <tr>
                    <td><label for="nome">Nome: </label></td>
                    <td><input type="text" name="cadNome"></td>
                </tr>

                <tr>
                    <td><label for="endereco">Endereco: </label></td>
                    <td><input type="text" id="endereco" name="cadEndereco"></td>
                </tr>

                <tr>
                    <td><label for="telefone">Telefone</label></td>
                    <td><input type="number" id="telefone" name="telefone"></td>
                </tr>

                <tr>
                    <td><label for="email">Email</label></td>
                    <td><input type="email" id="email" name="email"></td>
                </tr>

                <tr>
                    <td><label for="celular">Celular</label></td>
                    <td><input type="number" id="celular" name="celular"></td>
                </tr>

                <tr>
                    <td><label for="foto">Foto de Perfil</label></td>
                    <td><input type="file" name="arquivo"></td>
                </tr>

                <tr>
                    <td><button id="btnCadContato" type="submit" name="CadastraContato" class="btn-cadastra">Cadastrar</button></td>
                </tr>
            </table>

        </form>
    </div>
</body>
</html>

<?php
    extract($_POST);

    @$CadastraContato = $_POST["CadastraContato"];

    if(isset($CadastraContato))
    {
        $destino = 'imgs_perfil/'.$_FILES['arquivo']['name'];
        $arquivo_tmp = $_FILES['arquivo']['tmp_name'];

        move_uploaded_file($arquivo_tmp, $destino);

        include_once("class/connect.php");
        $obj = new connect();
        $resultado = $obj->conectarBanco();

        $sql = "INSERT INTO Agenda (Nome, endereco, telefone, email, celular, imagem, idfk) VALUES ('".$_POST["cadNome"]."', '".$_POST["cadEndereco"]."', '".$_POST["telefone"]."', '".$_POST["email"]."', '".$_POST["celular"]."', '".$destino."', '".$_SESSION['id']."');";
        
        $executando = $resultado->prepare($sql);

        if(empty($_POST["cadNome"]) || empty($_POST["cadEndereco"]) || empty($_POST["telefone"]) || empty($_POST["email"])  || empty($_POST["celular"]) )
        {  
            echo '<script>alert("Verifique os campos vazios");</script>';
            exit;
        }
        else
        {
            if($executando->execute())
            {
                echo '<script>alert("Cadastro Realizado com sucesso");</script>';
  //              header("location: cadastroContato.php");
            }
            else
            {
                echo "verificar sql";
            }
            
        }
    }

    unset($CadastraContato, $_POST["cadNome"], $_POST["cadEndereco"], $_POST["telefone"], $_POST["email"], $_POST["celular"], $sql);
    
?>