<?php
    session_name('sessaoLogin');
    session_start();
     $id = $_GET['var'];

     include_once("class/connect.php");
     $obj = new connect();
     $resultado = $obj->conectarBanco();
     $indice = 0;
     $sql = "SELECT * FROM Agenda WHERE id_agenda = ".base64_decode($id).";";
    
     $query = $resultado->prepare($sql);
     if($query->execute())
     {
        while($linha = $query->fetch(PDO::FETCH_ASSOC))
        {
            $linhas[$indice] = $linha;
            $indice++;
        }

     }


    if($_SESSION['agenda'] == FALSE)
    {
        session_destroy();
        header("location: login.php");
    }
?>

<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../CSS_Agenda/fonts/update.css">
    <title>Update de Informações</title>
</head>
<body>

    <header>
        <h1>Realize a Atualização dos Dados</h1>
        <a href="logoff.php"><button id="btn-log-off" name="LogOFF-btn">Log-off</button></a>
    </header>

    <form action="update.php?var=<?php echo $id;?>" method="post">
        <div class="border-table">
            <table>
                <tr>
                    <td><label for="nome">Nome: </label></td>
                    <td><input type="text" id="atualizaNome" name="atualizaNome" value="<? echo $linhas[0]["nome"];?>"></td>
                </tr>

                <tr>
                    <td><label for="endereco">Endereco: </label></td>
                    <td><input type="text" id="atualizaEndereco" name="atualizaEndereco" value="<? echo $linhas[0]["endereco"]; ?>"></td>
                </tr>

                <tr>
                    <td><label for="telefone">Telefone: </label></td>
                    <td><input type="number" id="atulizaNumero" name="atualizaNumero" value="<? echo $linhas[0]["telefone"]; ?>"></td>
                </tr>

                <tr>
                    <td><label for="email">Email: </label></td>
                    <td><input type="email" id="atualizaEmail" name="atualizaEmail" value="<? echo $linhas[0]["email"]; ?>"></td>
                </tr>

                <tr>
                    <td><label for="celular">Celular: </label></td>
                    <td><input type="number" id="atualizaCelular" name="atualizaCelular" value="<? echo $linhas[0]["celular"]; ?>"></td>
                </tr>

                <tr>
                    <td colspan="2"><button id="btnAtualiza" type="submit" name="botaoAtualiza">Atualizar</button></td>
                    <td colspan="2"><a href="agenda.php"><button id="btnCancela" type="button" name="botaoCancela">Cancelar</button></a></td>
                </tr>
            </table>
        </div>
    </form>
</body>
</html>

<?php
    extract ($_POST);
    if(isset($_POST["botaoAtualiza"]))
    {
        include_once("class/connect.php");
        $obj = new connect();
        $resultado = $obj->conectarBanco();

        $nome = $_POST['atualizaNome'];
        $endereco = $_POST['atualizaEndereco'];
        $telefone = $_POST['atualizaNumero'];
        $email = $_POST['atualizaEmail'];
        $celular = $_POST['atualizaCelular'];
        

        $sql = "UPDATE Agenda SET Nome='".$nome."', endereco='".$endereco."',telefone='".$telefone."',email='".$email."',celular='".$celular."' where id_agenda=".base64_decode($id).";";
    
        $query = $resultado->prepare($sql);
        if($query->execute())
        {
            echo '
            <script>alert("Atualizou!!!");</script>
            ';
        }
        else
        {
            echo "Não deu certo";
        }
        echo '
        <script>window.location.href = "agenda.php";</script>
        ';
    }

?>