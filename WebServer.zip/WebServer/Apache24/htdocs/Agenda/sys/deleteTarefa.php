<?php

    include_once("class/connect.php");

    $obj = new connect();
    $resultado = $obj->conectarBanco();

    if(isset($_GET['id']))
    {
        $id_tarefa = $_GET['id'];

        $sql = "DELETE FROM Tarefas WHERE id = :id";
        $stmt = $resultado->prepare($sql);
        $stmt->bindParam(':id', $id_tarefa);
        
        if($stmt->execute())
        {
            header("location: tarefas.php");
        }
    }
?>