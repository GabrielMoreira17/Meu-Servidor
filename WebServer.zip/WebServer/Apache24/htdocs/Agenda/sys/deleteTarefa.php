<?php

    include_once("class/connect.php");

    if(isset($_GET['id']))
    {
        $id = $_GET['id'];

        $sql = "DELETE FROM Tarefas WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':id', $id);
        $stmt->execute();

        header("location: tarefas.php");
    }
?>