<?php
echo $_GET['var'];

    include_once("class/connect.php");
    $obj = new connect();
    $resultado = $obj->conectarBanco();

     $sql = "DELETE FROM Agenda WHERE id_agenda = '".$_GET['var']."';";

    $executado = $resultado->prepare($sql);

    if($executado->execute())
    {
        echo '<script>alert("Deletado com Sucesso!!");</script>';
        header("location: agenda.php");
    }
?>