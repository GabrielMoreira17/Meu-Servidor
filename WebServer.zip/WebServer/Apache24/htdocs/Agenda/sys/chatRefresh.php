<?php
include_once("class/connect.php");
$obj = new connect();
$resultado = $obj->conectarBanco();

$sql = "SELECT nome, mensagem FROM Chat ORDER BY id_chat";
$query = $resultado->prepare($sql);

if ($query->execute()) {
    while ($linha = $query->fetch(PDO::FETCH_ASSOC)) {
        $nome = htmlspecialchars($linha['nome']);
        $mensagem = $linha['mensagem'];

        // Gerar uma cor única com base no hash do nome
        $cor = '#' . substr(md5($nome), 0, 6); // Gera uma cor a partir do hash do nome

        echo "<div class='message' style='color: $cor;'>";
        echo "<strong>" . $nome . ":</strong> ";
        echo $mensagem;
        echo "</div>";
    }
}
?>
