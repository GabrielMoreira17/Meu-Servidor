<?php
    session_name('sessaoLogin');
    session_start();

    if($_SESSION['agenda'] == FALSE)
    {
        session_destroy();
        header("location: index.php");
    }

?>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="css/agenda.css">
    <script src="js/script.js" defer></script>
    <title>Agenda</title>
</head>
<body>

    <header>
        <h1>Faça a sua Pesquisa</h1>
        <button id="btn-menu"><i class='menu bx bx-menu'></i></button>
    </header>        

    <div class="container"> 
        <nav class="nav-link">
            <ul>
                <li><a href="pagPerfil.php">Seu Perfil</a></li>
                <li><a href="chat.php">Chat</a></li>
                <li><a href="logoff.php">Sair</a></li>
            </ul>
        </nav>
    </div>
</body>
</html>

<?php

    extract ($_POST);


    if(isset($_POST["busca"]))
    {
        include_once("class/connect.php");
        $obj = new connect();
        $resultado = $obj->conectarBanco();

        $sql = "SELECT imagem, Nome, endereco, telefone, email, celular, id_agenda FROM Agenda WHERE Nome like UPPER('".$_POST["letra"]."%') AND idfk = '".$_SESSION['id']."'";
        $indice = 0;

        $executado = $resultado->prepare($sql);

        if($executado->execute())
        {
            while($linha = $executado->fetch(PDO::FETCH_ASSOC))
            {
                $linhas[$indice] = $linha;
                $indice++;
            }

            $i = 0;
           
            echo '
            <table class="tabela">
                    <tr>
                        <td>Foto</td>
                        <td>Nome</td>
                        <td>Endereco</td>
                        <td>Telefone</td>
                        <td>Email</td>
                        <td>Celular</td>
                        <td>Atualizar</td>
                        <td>Deletar</td>
                    </tr>';
            while($i < $indice)
            {
                if($i%2 != 0)
                {
                    $cor = "#FFFFFF;";
                }else{
                    $cor = "#CCCCCC;";
                }
            echo '
                
                    <tr style="background-color:'.$cor.'">
                        <td><img width="35px" src="'.$linhas[$i]['imagem'].'" /></td>
                        <td>'.$linhas[$i]['nome'].'</td>
                        <td>'.$linhas[$i]['endereco'].'</td>
                        <td>'.$linhas[$i]['telefone'].'</td>
                        <td>'.$linhas[$i]['email'].'</td>
                        <td>'.$linhas[$i]['celular'].'</td>  
                        <td><a href="update.php?var='.base64_encode($linhas[$i]["id_agenda"]).'"><button id="botaoUpdate" name="atualizar" type="submit">Atualizar Campos</button></a></td> 
                        <td><a href="delete.php?var='.$linhas[$i]["id_agenda"].'"><button id="botaoDelete" name="deletar" type="submit">Deletar Campos</button></a></td>
                    </tr>
            ';
            $i++;
            }
            echo '</table>';
        }
        else
        {
            echo "Deu errado cara!!";
        }
    }

    print'
    <div class="pesquisas">
    <form action="agenda.php" method="post">
        <div>
            <label for="pesquisa">Pesquisar: </label>
            <input type="text" id="letra" name="letra">
            <button id="botao" type="submit" name="busca">Buscar</button>
            <a href="cadastroContato.php"><button id="botao-cadastra" type="button" name="cadastra">Cadastrar Contato</button></a>
        </div>
    </form>
    </div>';

    unset($_POST["busca"],$_POST["nome"],$_POST["endereco"],$_POST["telefone"],$_POST["email"],$_POST["celular"]);
?>