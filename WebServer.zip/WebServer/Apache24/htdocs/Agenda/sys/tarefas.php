<?php
session_name("sessaoLogin");
session_start();

include("class/connect.php");

$obj = new connect();
$pdo = $obj->conectarBanco();

if (!$pdo) {
    die("Erro na conexão com o banco de dados.");
}


if (isset($_POST['adicionar'])) {
    $tarefa = htmlspecialchars($_POST['tarefa']);
    if (!empty($tarefa)) {
        $sql = "INSERT INTO Tarefas (tarefa) VALUES (:tarefa)";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':tarefa', $tarefa);
        $stmt->execute();
        header("Location: tarefas.php");
        exit();
    }
}

$sql = "SELECT * FROM tarefas ORDER BY data_criacao DESC";
$stmt = $pdo->query($sql);

if ($stmt) {
    $tarefas = $stmt->fetchAll();
    if (empty($tarefas)) {
        $tarefas = []; 
    }
} else {
    $tarefas = [];
}
?>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="css/ListaDeTarefas.css">
    <script src="js/script.js"></script>
    <title>Lista de Tarefas</title>
</head>
<body>  
    <header>
        <h1>Lista de Tarefas</h1>
    </header>

    <div class="container">
        <form action="tarefas.php" method="POST">
            <input type="text" name="tarefa" placeholder="Digite sua Tarefa" required>
            <button type="submit" name="adicionar">Adicionar</button>
        </form>

        <h2>Tarefas</h2>
        <ul>
            <?php foreach ($tarefas as $tarefa): ?>
            <li>
                <?php if ($tarefa['concluida'] == 1): ?>
                    <span class="concluida"><?php $tarefa['tarefa'] ?></span>
                <?php else: ?>
                    <?= $tarefa['tarefa'] ?>
                <?php endif; ?>
                <a href="tarefaConcluida.php? id=<?= $tarefa['id'] ?>">Marcar como concluída</a>
                <a href="delete_tarefa.php? id=<?= $tarefa['id'] ?>">Excluir</a>    
            </li>
            <?php endforeach; ?>
        </ul>
    </div>
</body>
</html>