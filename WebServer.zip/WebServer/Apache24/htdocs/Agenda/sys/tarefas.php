<?php
session_name("sessaoLogin");
session_start();

include("class/connect.php");

$obj = new connect();
$pdo = $obj->conectarBanco();

if (!$pdo) {
    die("Erro na conexão com o banco de dados.");
}


if (isset($_POST['adicionar'])) {
    $tarefa = htmlspecialchars($_POST['tarefa']);
    if (!empty($tarefa)) {
        $sql = "INSERT INTO Tarefas (tarefa,concluida,idfk) VALUES (:tarefa, FALSE, '".$_SESSION['id']."')";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':tarefa', $tarefa);
        $stmt->execute();
        header("Location: tarefas.php");
        exit();
    }
}

$sql = "SELECT * FROM tarefas WHERE concluida = FALSE ORDER BY data_criacao DESC";
$stmt = $pdo->query($sql);

if ($stmt) {
    $tarefas = $stmt->fetchAll();
    if (empty($tarefas)) {
        $tarefas = []; 
    }
} else {
    $tarefas = [];
}
?>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="css/ListaDeTarefas.css">
    <script src="js/script.js"></script>
    <title>Lista de Tarefas</title>
</head>
<body>  
    <header>
        <h1>Lista de Tarefas</h1>
        <button id="btn-menu"><i class='menu bx bx-menu'></i></button>
    </header>

    <div class="container">
    <nav class="nav-link">
        <ul>
            <li><a href="agenda.php">Agenda</a></li>
            <li><a href="pagPerfil.php">Seu Perfil</a></li>
            <li><a href="cadastroContato.php">Cadastrar Contatos</a></li>
            <li><a href="tarefas.php">Suas Tarefas</a></li>
            <li><a href="logoff.php">Sair</a></li>
        </ul>
    </nav>

        <form action="tarefas.php" method="POST">
            <input type="text" name="tarefa" placeholder="Digite sua Tarefa" required>
            <button type="submit" name="adicionar">Adicionar</button>
        </form>

        <h2>Tarefas</h2>
        <ul>
            <?php foreach ($tarefas as $tarefa): ?>
            <li>
                <?php 
                //print_r($tarefa);
                
                if ($tarefa['concluida'] == 1): ?>
                    <span class="concluida"><?php $tarefa['tarefa'] ?></span>
                <?php else: ?>
                    <?= $tarefa['tarefa'] ?>
                <?php endif; ?>
                <a href="tarefaConcluida.php?id=<?= $tarefa['id_tarefas'] ?>">Concluída</a>
                <a href="deleteTarefa.php?id=<?= $tarefa['id_tarefas'] ?>">Excluir</a>  
            </li>
            <?php endforeach; ?>
        </ul>
    </div>
</body>
</html>