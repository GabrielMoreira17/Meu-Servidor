<?php

	phpinfo();

?>
