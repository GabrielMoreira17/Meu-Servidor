<?php
include("class/connect.php");

$obj = new connect();
$pdo = $obj->conectarBanco();

if (!$pdo) {
    die("Falha na conexão com o banco de dados.");
}


if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "UPDATE Tarefas SET concluida = TRUE WHERE id_tarefas = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':id', $id_tarefa);
    
    if($stmt->execute()){
        header("Location: tarefas.php");
        exit();
    }
} else {
    echo "ID não fornecido.";
}
?>
