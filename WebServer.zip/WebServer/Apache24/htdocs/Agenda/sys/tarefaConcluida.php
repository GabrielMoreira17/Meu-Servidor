<?php
include("class/connect.php");  // Inclui a classe de conexão

// Criar a instância da classe connect e obter a conexão
$obj = new connect();
$pdo = $obj->conectarBanco();

// Verifique se a conexão foi bem-sucedida
if (!$pdo) {
    die("Falha na conexão com o banco de dados.");
}

// Verifica se o ID da tarefa foi passado
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Atualiza o status da tarefa para concluída (TRUE)
    $sql = "UPDATE Tarefas SET concluida = TRUE WHERE id_tarefas = :id";  // Use TRUE para o campo booleano
    $stmt = $pdo->prepare($sql);  // Prepara a consulta
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);  // Bind do parâmetro de ID
    $stmt->execute();  // Executa a consulta

    // Redireciona de volta para a página de tarefas
    header("Location: tarefas.php");
    exit();
} else {
    echo "ID não fornecido.";
}
?>
