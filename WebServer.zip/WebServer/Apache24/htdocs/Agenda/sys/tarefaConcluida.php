<?php
include("class/connect.php");

$obj = new connect();
$pdo = $obj->conectarBanco();

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "UPDATE Tarefas SET concluida = TRUE WHERE id_tarefas = :id;";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':id', $id);
    

    
    if($stmt->execute()){
        header("Location: tarefas.php");
        exit();
    }
} else {
    echo "ID não fornecido.";
}
?>
