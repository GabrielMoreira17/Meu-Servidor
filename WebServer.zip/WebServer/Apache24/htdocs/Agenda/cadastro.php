<?php
session_name('sessaoLogin');
session_start();

?>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="css/cadastroUser.css">
    <title>Cadastro PHP</title>
</head>

<body>

    <header>
        <h1>Faça seu cadastro de Usuário</h1>
        <a href="index.php"><button id="btn-login" name="login-btn">Login</button><i class='bx bxs-user-circle'></i></a>
    </header>

    <div class="Forms">
        <form method="post" action="cadastro.php">
            <table class="table table-striped">
                <tr>
                    <td><label for="nome">Nome Completo</label></td>
                    <td><input type="text" id="nome" name="Cad-nome"></td>
                </tr>

                <tr>
                    <td><label for="email">Email</label></td>
                    <td><input type="email" id="email" name="Cad-email"></td>
                </tr>

                <tr>
                    <td><label for="usuario">Usuario</label></td>
                    <td><input type="text" id="user" name="cad-user"></td>
                </tr>

                <tr>
                    <td><label for="password">Senha</label></td>
                    <td><input type="password" id="senha" name="Cad-senha"></td>
                </tr>

                <tr>
                    <td><label for="imagem">Adicione sua foto</label></td>
                    <td><input type="file" accept="image/png, image/jpeg"></td>
                </tr>

                <tr>
                    <td colspan="2" style="text-align: center;"><button id="Cad-btn" type="submit" name="cadastrar">Cadastre-se</button></td>
                </tr>
            </table>
        </form>
    </div>

</body>

</html>

<?php
extract($_POST);

if (isset($_POST["cadastrar"])) {
    if ($_POST["Cad-nome"] == "") {


        unset($_POST["Cad-nome"], $_POST["cadastrar"]);
        echo '
           <script>window.location.href = "cadastro.php";</script>
           ';
    }

    if (isset($_POST["Cad-nome"])) {
        include_once("sys/class/connect.php");
        $obj = new connect();
        $resultado = $obj->conectarBanco();

        $logincriptografado = md5($_POST["cad-user"]);
        $senhacriptografada = md5($_POST["Cad-senha"]);


        $sql = "INSERT INTO Users (usuario, email, nome, passwd, ativo) VALUES ('" . $logincriptografado . "', '" . $_POST["Cad-email"] . "', '".$_POST["Cad-nome"]."', '" . $senhacriptografada . "', TRUE);";

        $query = $resultado->prepare($sql);
        if ($query->execute()) {
            if ($logincriptografado == " " && $senhacriptografada == " ") {
                exit;
            }
            echo "Usuário cadastrado";
            header("location: cadastro.php");
        } else {
            echo "Não foi possivel cadastrar Usuário";
        }
    }
}

unset($_POST["cad-user"] ,$_POST["Cad-nome"], $_POST["Cad-email"], $_POST["Cad-senha"], $sql);
?>