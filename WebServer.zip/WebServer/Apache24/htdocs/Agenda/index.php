<?php
    session_name('sessaoLogin');
    session_start();
?>

<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="css/login.css">
    <title>Login</title>
</head>
<body>

    <header>
        <h1>Faça seu Login ou Cadastre-se</h1>
    </header>
<!--Inicio do formulário de login-->
    <form action="index.php" method="post">
    <!--Inicio da Tabela-->
        <table border="1">
            <tr>
                <td><label for="name">Usuario:</label></td>
                <td colspan="2"><input type="text" id="name" name="name" required><i class='bx bxs-user-circle' ></i></td>
            </tr>

            <tr>
                <td><label for="password">Senha:</label></td>
                <td colspan="2"><input type="password" id="password" name="passwd" required><i class='bx bxs-lock-alt'></i></td>
            </tr>

            <tr>
                <td colspan="3" id="textos"><a id="recupera" href="sys/rec uperaSenha.php">Recuperar Senha</a>
                    <label for="remember-password" id="lembra-senha">Lembrar-me a Senha</label>
                    <input type="checkbox" name="lembra-senha" id="lembra-senha">
                </td>
            </tr>

            <tr>
                <td colspan="3" style="text-align: center;"><button id="button" type="submit" name="entrar">Entrar</button>
                <a href="cadastro.php"><button id="button-Cad" type="button" name="Cadastre-se">Cadastre-se</button></a></td>
            </tr>

        </table>
    <!--Fim da Tabela-->
    </form>
<!--Fim do formulário de login-->
</body>
</html>

<?php

    extract($_POST);
    if(isset($_POST["entrar"]))
    {
        include_once("sys/class/connect.php");
        $obj = new connect();
        $resultado = $obj->conectarBanco();

        $sql = "SELECT id, usuario, passwd FROM Users WHERE usuario ='".md5($_POST["name"])."'AND passwd = '".md5($_POST ["passwd"])."' AND ativo = TRUE;";
        
        $query = $resultado->prepare($sql);
        $indice = 0;
        if ($query->execute())
        {
            while($linha = $query->fetch(PDO::FETCH_ASSOC))
            {
                $linhas[$indice] = $linha;
                $indice++;
            }
            if($indice == 1)
            {
                $_SESSION['agenda'] = TRUE;
                $_SESSION['id'] = $linhas[0]["id"];
                header("location: sys/agenda.php");
            } 
            else 
            {
                echo '
                    <p class="msg-erro">Login ou Senha não existem</p>
                ';

                $nomeArquivo = 'logs/log.txt';
                $ip_usuario = $_SERVER['REMOTE_ADDR'].'-'.$_SERVER['SERVER_ADDR'];

                $arquivo = fopen($nomeArquivo, 'a+');

                if($arquivo)
                {
                    $conteudo = "\nLogin realizado com usuário não cadastrado. \n";
                    $conteudo .= date('d/m/Y')."\n";
                    $conteudo .= $_POST["name"]." - ".$_POST ["passwd"]."\n";
                    $conteudo .= "IP: " .$ip_usuario . "\n\n";
                    
                    fwrite($arquivo, $conteudo);
                    fclose($arquivo);
                }
            }
        }

        unset($_POST["entrar"], $_POST["name"], $_POST["passwd"]);
    }
?>