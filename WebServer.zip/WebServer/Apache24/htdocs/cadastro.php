<?php
session_name('sessaoLogin');
session_start();

?>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../styles/cadastroCliente.css">
    <title>Cadastro PHP</title>
</head>

<body>

    <header>
        <h1>Faça seu cadastro de Usuário</h1>
        <a href="login.php"><button id="btn-login" name="login-btn">Login</button><i class='bx bxs-user-circle'></i></a>
    </header>

    <div class="Forms">
        <form method="post" action="cadastro.php">
            <table>
                <tr>
                    <td><label for="nome">Nome Completo</label></td>
                    <td><input type="text" id="nome" name="Cad-nome" value=""></td>
                </tr>

                <tr>
                    <td><label for="email">Email</label></td>
                    <td><input type="email" id="email" name="Cad-email"></td>
                </tr>

                <tr>
                    <td><label for="password">Senha</label></td>
                    <td><input type="password" id="senha" name="Cad-senha"></td>
                </tr>

                <tr>
                    <td colspan="2" style="text-align: center;"><button id="Cad-btn" type="submit" name="cadastrar">Cadastre-se</button></td>
                </tr>
            </table>
        </form>
    </div>

</body>

</html>

<?php
extract($_POST);

if (isset($_POST["cadastrar"])) {
    if ($_POST["Cad-nome"] == "") {


        unset($_POST["Cad-nome"], $_POST["cadastrar"]);
        echo '
           <script>window.location.href = "cadastro.php";</script>
           ';
    }

    if (isset($_POST["Cad-nome"])) {
        include_once("connect.php");
        $obj = new connect();
        $resultado = $obj->conectarBanco();

        $logincriptografado = md5($_POST["Cad-nome"]);
        $senhacriptografada = md5($_POST["Cad-senha"]);


        $sql = "INSERT INTO Users (usuario, email, passwd) VALUES ('" . $logincriptografado . "', '" . $_POST["Cad-email"] . "', '" . $senhacriptografada . "');";

        $query = $resultado->prepare($sql);
        if ($query->execute()) {
            if ($logincriptografado == " " && $senhacriptografada == " ") {
                exit;
            }
            echo "Usuário cadastrado";
            header("location: cadastro.php");
        } else {
            echo "Não foi possivel cadastrar Usuário";
        }
    }
}

unset($_POST["Cad-nome"], $_POST["Cad-email"], $_POST["Cad-senha"], $sql);
?>