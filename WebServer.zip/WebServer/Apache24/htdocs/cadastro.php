
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles/cadastroCliente.css">
    <title>Cadastro PHP</title>
</head>
<body>

<div class="Forms">
    <form method="post" action="cadastro.php" >
        <label for="nome">Nome Completo</label>
        <input type="text" id="nome" name="Cad-nome">
        <br>
        <label for="email">Email</label>
        <input type="email" id="email" name="Cad-email">
        <br>
        <label for="password">Senha</label>
        <input type="password" id="senha" name="Cad-senha">

        <button id="Cad-btn" type="submit" name="cadastrar">Cadastre-se</button>
    </form>
</div>
</body>
</html>

<?php
    extract($_POST);
    
    if(isset($_POST["cadastrar"]))
    {
        echo "teste";
        include_once("connect.php");
        $obj = new connect();
        $resultado = $obj->conectarBanco();

        $logincriptografado = md5($_POST["Cad-nome"]);
        $senhacriptografada = md5($_POST["Cad-senha"]);


        $sql = "INSERT INTO Users (usuario, email, passwd) VALUES ('".$logincriptografado."', '".$_POST["Cad-email"]."', '".$senhacriptografada."');";

        $query = $resultado->prepare($sql);
        if($query->execute())
        {
            echo "Usuário cadastrado";
        }
        else
        {
            echo "Não foi possivel cadastrar Usuário";
        }
    }

    unset($_POST["Cad-nome"], $_POST["Cad-email"], $_POST["Cad-senha"], $sql);
?>