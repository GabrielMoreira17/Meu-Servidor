<?php
    session_name('sessaoLogin');
    session_start();
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../styles/recuperaSenha.css">
    <title>Recupere sua Senha</title>
</head>
<body>
    <header>
        <h1>Recupere sua Senha</h1>
        <a href="login.php"><button id="btn-login" name="login-btn">Login</button></a>
    </header>

    <form action="recuperaSenha.php" method="post">
        <table border="2">
            <tr>
                <td>
                    <label for="email">Digite seu email</label>
                    <input type="email" name="email" id="email-rec" placeholder="Email de recuperação" required>
                </td>

                <tr>
                    <td>
                        <label for="senha">Digite seu telefone</label>
                        <input type="number" name="telefone" id="telefone-rec" placeholder="Telefone de recuperação" required>
                    </td>
                </tr>

                <tr>
                    <td colspan="3" style="text-align: center;">
                        <button>Recuperar Senha</button>
                    </td>
                </tr>
            </tr>
        </table>
    </form>
</body>
</html>