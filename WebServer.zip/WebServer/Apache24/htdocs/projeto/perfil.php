<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="./CSSprojeto/perfil.css">
    <title>LearnLab</title>
</head>
<body>
<!--Inicio do header-->
    <header class="menu">
    <button id="btn-menu"><i class='bx bxs-home' ></i></button>
    <h1>PERFIL</h1>
    </header>
<!--Fim do header-->

<!--Icon Perfil-->
<div class="perfil">
    <i class='perfil bx bxs-user-circle'></i>
</div>
<!--Fim do icon Perfil-->

<!--Inicio dos campos--->
<div class="fundo_perfil">
<form action="perfil.php">
    <input type="text" name="nome" id="nome_perfil" placeholder="Nome Completo">

    <input type="email" name="email" id="email_perfil" placeholder="Email">

    <input type="text" name="descricao" id="descricao_perfil" placeholder="Descrição">

    <input type="text" name="redes_Sociais" id="Redes_Sociais" placeholder="Redes Sociais">

    <textarea name="cursos" id="cursos" placeholder="Cursos já realizados e experiências"></textarea>
</form>
</div>
<!--Fim dos campos--->

<!--Inicio do footer-->
<footer>
    <div class="icons_footer">
        <a href="Cursos.php"><i class='bx bxs-book-alt'></i></a>
    </div>
</footer>
<!--Fim do footer-->
</body>
</html>

<?php
    extract($_POST);
    if(isset($_POST["entrar"]))
    {
        include_once("projeto/connect/connect.php");
        $obj = new connect();
        $resultado = $obj->conectarBanco();
    }

?>