<?php
session_start();
$_SESSION['id'] = 2;

include_once("connect/connect.php");
        $obj = new connect();
        $resultado = $obj->conectarBanco();

        $sql = "SELECT C.nomeCompleto, P.descricao, P.cursosExperiencia, P.id_perfil, C.email 
                FROM Perfil P
                INNER JOIN Cadastro C ON P.user_idfk = C.id_user
                WHERE id_perfil = ".$_SESSION['id']." ORDER BY id_perfil;";
        $indice = 0;

        $executado = $resultado->prepare($sql);

        if($executado->execute())
        {
            while($linha = $executado->fetch(PDO::FETCH_ASSOC))
            {
                $linhas[$indice] = $linha;
                $indice++;
            }
        }
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="./CSSprojeto/perfil.css">
    <title>LearnLab</title>
</head>

<body>
    <header class="menu">
    <a href="pagInicial.php"><button id="btn-menu"><i class='bx bxs-home' ></i></button></a>
    <h1>PERFIL</h1>
    </header>

<div class="perfil">
    <i class='perfil bx bxs-user-circle'></i>
</div>

<div class="fundo_perfil">
<form action="perfil.php" method="post">
<input readonly type="hidden"  name="idPerfil" id="id_perfil" placeholder="Nome Completo" value="<? echo $linhas[0]["id_perfil"];?>">
    <input readonly type="text" name="nomePerfil" id="nome_perfil" placeholder="Nome Completo" value="<? echo $linhas[0]["nomecompleto"];?>">

    <input readonly type="text" name="redes_Sociais" id="Redes_Sociais" placeholder="Redes Sociais" value="<? echo $linhas[0]["email"]; ?>">

    <input type="text" name="descricao" id="descricao_perfil" placeholder="Adicione uma breve descrição" value="<? echo $linhas[0]["descricao"];?>">

    <textarea name="cursos" id="cursos" placeholder="Adicione caso possua Cursos e/ou Experiência"><?php echo $linhas[0]["cursosexperiencia"];?></textarea>

    <button id="btn-adiciona" type="submit" name="adiciona">Adicionar Informações</button>
</form>
</div>

<footer>
    <div class="icons_footer">
        <a href="cursosPessoais.php"><i class='bx bxs-book-alt'></i></a>
    </div>
</footer>
</body>
</html>

<?php
    extract($_POST);
    if(isset($_POST["adiciona"]))
    {
        include_once("connect/connect.php");
        $obj = new connect();
        $resultado = $obj->conectarBanco();

        $descricao = $_POST['descricao'];
        $cursos = $_POST['cursos'];
        $id = $_POST['idPerfil'];

        $sql = "UPDATE Perfil SET descricao = '".$descricao."', cursosexperiencia = '".$cursos."' WHERE id_perfil = ".$id.";";
        $queryUpdate = $resultado->prepare($sql);

        if($queryUpdate->execute())
        {
            echo "<script>alert('Informações atualizadas com sucesso!');</script>";
            header("Location: perfil.php");
        }
        else
        {
            echo "<script>alert('Erro ao alterar a suas informações.');</script>";
        }
    }
?>