<?php
session_start();
$_SESSION['id_user'] = 1;

include_once("connect/connect.php");
        $obj = new connect();
        $resultado = $obj->conectarBanco();

         $sql = "SELECT C.nomeCompleto, P.descricao, P.cursosExperiencia, P.id_perfil, C.email,P.curriculo_url 
                FROM Perfil P
                INNER JOIN Cadastro C ON P.user_idfk = C.id_user
                WHERE user_idfk = ".$_SESSION['id_user'].";";
        $indice = 0;

        $executado = $resultado->prepare($sql);

        if($executado->execute())
        {
            while($linha = $executado->fetch(PDO::FETCH_ASSOC))
            {
                $linhas[$indice] = $linha;
                $indice++;
            }
        }
?>
<html lang="PT-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="./CSSprojeto/perfil.css">
    <title>LearnLab</title>
</head>
<body>
<!--Cabeçalho da Página-->
<header class="menu">
    <a href="pagInicial.php"><button id="btn-menu"><i class='bx bxs-home' ></i></button></a>
    <h1>PERFIL</h1>
</header>
<!--Fim do cabeçalho da página-->

<!--Div que contém o icone do usuário-->
<div class="perfil">
    <i class='perfil bx bxs-user-circle'></i>
</div>
<!--Fim da div que contém o icone do usuário-->

<!--Div que fica engloba o formulario-->
<div class="fundo_perfil">
<form action="perfil.php" method="post">
<input readonly type="hidden"  name="idPerfil" id="id_perfil" placeholder="Nome Completo" value="<? echo $linhas[0]["id_perfil"];?>">
    <input readonly type="text" name="nomePerfil" id="nome_perfil" placeholder="Nome Completo" value="<? echo $linhas[0]["nomecompleto"];?>">

    <input readonly type="text" name="redesSociais" id="Redes_Sociais" placeholder="Redes Sociais" value="<? echo $linhas[0]["email"]; ?>">

    <input type="text" name="descricao" id="descricao_perfil" placeholder="Adicione uma breve descrição" value="<? echo $linhas[0]["descricao"];?>">

    <textarea name="cursos" id="cursos" placeholder="Adicione caso possua Cursos e/ou Experiência"><?php echo $linhas[0]["cursosexperiencia"];?></textarea>

    <a target="blank" href="<?php echo $linhas[0]['curriculo_url'];?>">Curriculo</a>

    <button id="btn-adiciona" type="submit" name="adiciona">Alterar Informações</button>
</form>
</div>
<!--Fim da div que fica engloba o formulario-->

<!--Div que da acesso as navegações das páginas-->
<footer>
    <div class="icons_footer">
        <a href="cursosPessoais.php"><i class='bx bxs-book-alt'></i></a>
    </div>
</footer>
<!--Fim da div que da acesso as navegações das páginas-->
</body>
</html>

<?php
    extract($_POST);
    if(isset($_POST["adiciona"]))
    {
        include_once("connect/connect.php");
        $obj = new connect();
        $resultado = $obj->conectarBanco();
        
        $descricao = $_POST["descricao"];
        $cursos = $_POST["cursos"];

        $sql = "UPDATE Perfil SET descricao = '".$descricao."', cursosExperiencia = '".$cursos."';";
        
        $queryUpdate = $resultado->prepare($sql);

        //Executa a atualização
        if($queryUpdate->execute())
        {
            //Se executado corretamente exibe uma mensagem e da um refresh na página
            echo "<script>alert('Informações atualizadas com sucesso!');</script>";
            header("Location: perfil.php");
        }
        else
        {
            //Em caso de erro mostra um alerta na tela
            echo "<script>alert('Erro ao alterar a suas informações.');</script>";
        }
    }
?>