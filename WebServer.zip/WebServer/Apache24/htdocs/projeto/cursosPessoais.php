<?php
    include_once("connect/connect.php");
    $obj = new connect();
    $resultado = $obj->conectarBanco();

    $sql = "SELECT * FROM CursosPessoais;";
    $indice = 0;

    $executado = $resultado->prepare($sql);

    if($executado-execute())
    {
        while($linha = $executado-fetch(PDO::FETCH_ASSOC))
        {
            $linhas[$indice] = $linha;
            $indice++;
        }
    }
?>


<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="./CSSprojeto/Cursos.css">
    <title>Cursos Pessoais</title>
</head>
<body>
<!--Inicio do header-->
    <header class="cabecalho">
    <a href="paginaInicial.php"><button id="btn-menu"><i class='bx bxs-home' ></i></button></a>
    <h1>CURSOS PESSOAIS</h1>
    </header>
<!--Fim do header-->

        <div class="titulo">
            <h1>EM ANDAMENTO</h1>
        </div>

        <!--Inicio dos cards de Cursos em Andamento-->
        <div class="cards_andamento">
            <div class="card" name="NomeCursoPessoal" value="<? echo $linhas[0]["NomeCursoPessoal"];?>"></div>
            <div class="card"></div>
            <div class="card"></div>
            <div class="card"></div>
            <div class="card"></div>
        </div>
        <!--Fim dos cards de Cursos em Andamento-->

        <!--Inicio dos cards de Cursos Finalizados-->
        <div class="titulo_finalizados">
            <h1>FINALIZADOS</h1>
        </div>

        <div class="cards_finalizados">
            <div class="card_finalizado"></div>
            <div class="card_finalizado"></div>
            <div class="card_finalizado"></div>
            <div class="card_finalizado"></div>
            <div class="card_finalizado"></div>
        </div>
        <!--Fim dos cards de Cursos Finalizados-->

<!--Inicio do footer-->
<footer>
    <div class="icons_footer">
        <a href="perfil.php"><button id="btn_user" name="botao_perfil" type="submit"><i class='bx bxs-user-circle' ></i></button></a>
    </div>
</footer>
<!--Fim do footer-->
</body>
</html>

