<?php
    include_once("connect/connect.php");
    $obj = new connect();
    $resultado = $obj->conectarBanco();

    $sql = "SELECT * FROM CursosPessoais;";
    $indice = 0;

    $executado = $resultado->prepare($sql);

    if($executado->execute())
    {
        while($linha = $executado->fetch(PDO::FETCH_ASSOC))
        {
            $linhas[$indice] = $linha;
            $indice++;
        }
    }
?>


<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="./CSSprojeto/Cursos.css">
    <title>Cursos Pessoais</title>
</head>
<body>

    <header class="cabecalho">
        <a href="paginaInicial.php"><button id="btn-menu"><i class='bx bxs-home' ></i></button></a>
        <h1>CURSOS PESSOAIS</h1>
    </header>

        <div class="titulo">
            <h1>EM ANDAMENTO</h1>
        </div>
        <br /><br /><br /><br />
        <div class="cards_andamento">
            <div class="imagem"></div>
        <?php
        $indice = $indice;
        for($i = 0; $i <$indice; $i++ )
        {
            print '
            
                <div class="card" name="NomeCursoPessoal"><a href="detalhesCurso">'.$linhas[$i]["nomecursopessoal"].'<br />
                '.$linhas[$i]["duracaocursopessoal"].'</a></div>';
        }
        ?>
        </div>
        <div class="titulo_finalizados">
            <h1>FINALIZADOS</h1>
        </div>
        
        <div class="cards_andamento">
        <div class="imagemF"></div>
        <?php
        $indice = $indice;
        for($i = 0; $i <$indice; $i++ )
        {
            print '
            
                    <div class="card" name="NomeCursoPessoal"><a href="detalhesCurso">'.$linhas[$i]["nomecursopessoal"].'<br />
                '.$linhas[$i]["duracaocursopessoal"].'</a></div>';
        }
        ?>
        </div>

<footer>
    <div class="icons_footer">
        <a href="perfil.php"><button id="btn_user" name="botao_perfil" type="submit"><i class='bx bxs-user-circle' ></i></button></a>
    </div>
</footer>
</body>
</html>

