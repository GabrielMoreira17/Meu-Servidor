<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="./CSSprojeto/Cursos.css">
    <title>Cursos Pessoais</title>
</head>
<body>
<!--Inicio do header-->
    <header class="cabecalho">
    <button id="btn-menu"><i class='bx bxs-home' ></i></button>
    <h1>Cursos Pessoais</h1>
    </header>
<!--Fim do header-->

<!--Inicio Container-->
    <div class="container">
        <div class="titulo">
            <h1>Em Andamento</h1>
        </div>

        <div class="cards">
            <div class="card"></div>
        </div>
    </div>
<!--Fim Container-->

<!--Inicio do footer-->
<footer>
    <div class="icons_footer">
        <i class='bx bxs-book-alt'></i>
        <i class='bx bxs-user-circle' ></i>
    </div>
</footer>
<!--Fim do footer-->
</body>
</html>