<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../styles/update.css">
    <title>Update de Informações</title>
</head>
<body>

    <header>
        <h1>Realize a Atualização dos Dados</h1>
        <a href="logoff.php"><button id="btn-log-off" name="LogOFF-btn">Log-off</button></a>
        <a href="agenda.php"><button id="btn-agenda">Agenda</button></a>
    </header>

    <form action="update.php" method="post">
        <div class="border-table">
            <table>
                <tr>
                    <td><label for="nome">Nome: </label></td>
                    <td><input type="text" id="atualizaNome" name="atualizaNome"></td>
                </tr>

                <tr>
                    <td><label for="endereco">Endereco: </label></td>
                    <td><input type="text" id="atualizaEndereco" name="atualizaEndereco"></td>
                </tr>

                <tr>
                    <td><label for="telefone">Telefone: </label></td>
                    <td><input type="number" id="atulizaNumero" name="atualizaNumero"></td>
                </tr>

                <tr>
                    <td><label for="email">Email: </label></td>
                    <td><input type="email" id="atualizaEmail" name="atualizaEmail"></td>
                </tr>

                <tr>
                    <td><label for="celular">Celular: </label></td>
                    <td><input type="number" id="atualizaCelular" name="atualizaCelular"></td>
                </tr>

                <tr>
                    <td><label for="id">Id: </label></td>
                    <td><input type="number" id="atualizaId" name="atualizaId"></td>
                </tr>

                <tr>
                    <td colspan="2"><button id="btnAtualiza" type="submit" name="botaoAtualiza">Atualizar</button></td>
                    <td colspan="2"><a href="agenda.php"><button id="btnCancela" type="button" name="botaoCancela">Cancelar</button></a></td>
                </tr>
            </table>
        </div>
    </form>
</body>
</html>

<?php
    extract ($_POST);
    if(isset($_POST["botaoAtualiza"]))
    {
        include_once("connect.php");
        $obj = new connect();
        $resultado = $obj->conectarBanco();

        $id = $_POST['atualizaId'];
        $nome = $_POST['atualizaNome'];
        $endereco = $_POST['atualizaEndereco'];
        $telefone = $_POST['atualizaNumero'];
        $email = $_POST['atualizaEmail'];
        $celular = $_POST['atualizaCelular'];
        

        $sql = "SELECT * FROM Agenda WHERE id = $id";
        $sql = "UPDATE Agenda SET Nome='".$nome."', endereco='".$endereco."',telefone='".$telefone."',email='".$email."',celular='".$celular."' where id_agenda=".$id.";";
    
        $query = $resultado->prepare($sql);
        if($query->execute())
        {
            echo "Atualizou";
        }
        else
        {
            echo "Não deu certo";
        }
    }

?>