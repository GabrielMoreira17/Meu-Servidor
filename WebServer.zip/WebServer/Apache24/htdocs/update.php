<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update de Informações</title>
</head>
<body>
    <form action="update.php" method="post">
        <div class="atualiza">
            <label for="nome">Nome: </label>
            <input type="text" id="atualizaNome" name="atualizaNome">

            <label for="endereco">Endereco: </label>
            <input type="text" id="atualizaEndereco" name="atualizaEndereco">

            <label for="telefone">Telefone: </label>
            <input type="number" id="atulizaNumero" name="atualizaNumero">

            <label for="email">Email: </label>
            <input type="email" id="atualizaEmail" name="atualizaEmail">

            <label for="celular">Celular: </label>
            <input type="number" id="atualizaCelular" name="atualizaCelular">

            <button id="btnAtualiza" type="submit" name="botaoAtualiza">Atualizar</button>
        </div>
    </form>
</body>
</html>

<?php
    extract ($_POST);
    if(isset($_POST["botaoAtualiza"]))
    {
        include_once("connect.php");
        $obj = new connect();
        $resultado = $obj->connectBanco();

        $id = $_POST['id'];
        $nome = $_POST['atualizaNome'];
        $endereco = $_POST['atualizaEndereco'];
        $telefone = $_POST['atualizaTelefone'];
        $email = $_POST['atualizaEmail'];
        $celular = $_POST['atualizaCelular'];
        
echo $sql = "UPDATE Contatos SET nome='".$_POST["nome"]."',endereco='".$_POST["endereco"]."',telefone='".$_POST["telefone"]."',email='".$_POST["email"]."',celular='".$_POST["celular"]."' where id=1;";
    }


?>