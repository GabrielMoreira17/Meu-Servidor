<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update de Informações</title>
</head>
<body>
    <form action="update.php" method="post">
        <div class="atualiza">
            <label for="nome">Nome: </label>
            <input type="text" id="atualizaNome" name="atualizaNome">
            <br><br>

            <label for="endereco">Endereco: </label>
            <input type="text" id="atualizaEndereco" name="atualizaEndereco">
            <br><br>

            <label for="telefone">Telefone: </label>
            <input type="number" id="atulizaNumero" name="atualizaNumero">
            <br><br>

            <label for="email">Email: </label>
            <input type="email" id="atualizaEmail" name="atualizaEmail">
            <br><br>

            <label for="celular">Celular: </label>
            <input type="number" id="atualizaCelular" name="atualizaCelular">
            <br><br>

            <label for="id">Id: </label>
            <input type="number" id="atualizaId" name="atualizaId">
            <br><br>

            <button id="btnAtualiza" type="submit" name="botaoAtualiza">Atualizar</button>
        </div>
    </form>
</body>
</html>

<?php
    extract ($_POST);
    if(isset($_POST["botaoAtualiza"]))
    {
        include_once("connect.php");
        $obj = new connect();
        $resultado = $obj->conectarBanco();

        $id = $_POST['atualizaId'];
        $nome = $_POST['atualizaNome'];
        $endereco = $_POST['atualizaEndereco'];
        $telefone = $_POST['atualizaNumero'];
        $email = $_POST['atualizaEmail'];
        $celular = $_POST['atualizaCelular'];
        

        $sql = "SELECT * FROM Agenda WHERE id = $id";
        $sql = "UPDATE Agenda SET Nome='".$nome."', endereco='".$endereco."',telefone='".$telefone."',email='".$email."',celular='".$celular."' where id_agenda=".$id.";";
    
        $query = $resultado->prepare($sql);
        if($query->execute())
        {
            echo "Atualizou";
        }
        else
        {
            echo "Não deu certo";
        }
    }

?>