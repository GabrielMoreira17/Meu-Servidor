<?php
    session_name('sessaoLogin');
    session_start();
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página</title>
</head>
<body>
    
    <form action="login.php" method="post">
        <label for="name">Usuario:</label>
        <input type="text" id="name" name="name" required>
        <br><br>
        
        <label for="password">Senha:</label>
        <input type="password" id="password" name="passwd" required>
        <br><br>
        
        <button id="button" type="submit" name="entrar">Entrar</button>
    </form>
</body>
</html>

<?php


    extract($_POST);
    if(isset($_POST["entrar"]))
    {
        include_once("connect.php");
        $obj = new connect();
        $resultado = $obj->conectarBanco();

        $sql = "SELECT usuario, passwd FROM Users WHERE usuario ='".md5($_POST["name"])."'AND passwd = '".md5($_POST ["passwd"])."';";
        
        $query = $resultado->prepare($sql);
        $indice = 0;
        if ($query->execute())
        {
            while($linha = $query->fetch(PDO::FETCH_ASSOC))
            {
                $linhas[$indice] = $linha;
                $indice++;
            }
            if($indice == 1)
            {
                $_SESSION['agenda'] = TRUE;
                header("location: agenda.php");
            } 
            else
            {
                echo "Usuario e Senha não existe.";
            }
        }

        unsset($_POST["entrar"], $_POST["name"], $_POST["passwd"]);
    }
?>