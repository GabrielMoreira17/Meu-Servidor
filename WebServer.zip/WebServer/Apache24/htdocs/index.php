<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP</title>
</head>
<body>
    <style>
        h1
        {
            color: red;
        }

        p
        {
            color: green;
        }
    </style>

    Oi esse é meu teste

<?php
    $var = "Cachorro";
    $var2 = 20.5;
    $Soma = $var.$var2;
    
    echo "<ul>";
    for($i = 0; $i<100; $i++)
    {
        echo "<li>$i</li>";
    }
    echo "</ul>";
    
    echo "<p>$Soma</p>";
    
    printf("<h1>Olá mundo</h1> <br/>");
    
    echo "Imprimido";
?>
</body>
</html>