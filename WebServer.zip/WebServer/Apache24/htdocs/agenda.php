<?php
    session_name('sessaoLogin');
    session_start();

    if($_SESSION['agenda'] == FALSE)
    {
        session_destroy();
        header("location: login.php");
    }

?>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/agenda.css">
    <title>Agenda</title>
</head>
<body>

    <header>
        <h1>Faça a sua Pesquisa</h1>
    </header>

    <form action="agenda.php" method="post">
        <div class="pesquisas">
            <label for="pesquisa">Pesquisar: </label>
            <input type="text" id="letra" name="letra">
            <button id="botao" type="submit" name="busca">Buscar</button>
        </div>
    </form>
</body>
</html>

<?php

    extract ($_POST);
    if(isset($_POST["busca"]))
    {
        include_once("connect.php");
        $obj = new connect();
        $resultado = $obj->conectarBanco();

        $sql = "SELECT Nome, endereco, telefone, email, celular, id_agenda FROM Agenda WHERE Nome like '".$_POST["letra"]."%' AND idfk = '".$_SESSION['agenda']."'";
        $indice = 0;

        $executado = $resultado->prepare($sql);

        if($executado->execute())
        {
            while($linha = $executado->fetch(PDO::FETCH_ASSOC))
            {
                $linhas[$indice] = $linha;
                $indice++;
            }

            $i = 0;
           
            echo '
            <table class="tabela">
                    <tr>
                        <td>Nome</td>
                        <td>Endereco</td>
                        <td>Telefone</td>
                        <td>Email</td>
                        <td>Celular</td>
                        <td>Id</td>
                    </tr>';
            while($i < $indice)
            {
                if($i%2 != 0)
                {
                    $cor = "#FFFFFF;";
                }else{
                    $cor = "#CCCCCC;";
                }
            echo '
                
                    <tr style="background-color:'.$cor.'">
                        <td>'.$linhas[$i]['nome'].'</td>
                        <td>'.$linhas[$i]['endereco'].'</td>
                        <td>'.$linhas[$i]['telefone'].'</td>
                        <td>'.$linhas[$i]['email'].'</td>
                        <td>'.$linhas[$i]['celular'].'</td>  
                        <td><a href="update.php?var='.$linhas[$i]["id_agenda"].'"><button id="botaoUpdate" name="atualizar" type="submit">Atualizar Campos</button></a></td> 
                    </tr>
            ';
            $i++;
            }
            echo '</table>';
        }
        else
        {
            echo "Deu errado cara!!";
        }
    }
    unset($_POST["busca"],$_POST["nome"],$_POST["endereco"],$_POST["telefone"],$_POST["email"],$_POST["celular"]);
?>