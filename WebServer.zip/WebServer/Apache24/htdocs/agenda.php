<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/styles/agenda.css">
    <title>Agenda</title>
</head>
<body>

    <form action="agenda.php">
        <table>
         <tr>   
            <td><label for="name">Nome: </label></td>
            <td><input type="text" id="name" name="nome" required></td>
        </tr>
        
        <tr>
        <td><label for="endereco">Endereco: </label></td>
        <td><input type="text" id="endereco" name="endereco" required></td>
        </tr>

        <tr>
        <td><label for="telefone">Telefone: </label></td>
        <td><input type="number" id="telefone" name="telefone" required></td>
        </tr>

        <tr>
        <td><label for="email">Email: </label></td>
        <td><input type="email" id="email" name="email" required></td>
        </tr>
        
        <tr>
        <td><label for="celular">Celular</label></td>
        <td><input type="number" id="celular" name="celular" required></td>
        </tr>
            
        <tr>
        <td colspan="2"><button id="botao" type="submit" name="busca">Buscar</button></td>
        </tr>    
    </table>
        
    </form>
</body>
</html>

<?php

    extract ($_POST);
    if(isset($_POST["busca"]))
    {
        include_once("conect.php");
        $obj = new connect();
        $resultado = obj->conectarBanco();
    }
?>