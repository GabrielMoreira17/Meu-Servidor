<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles/agenda.css">
    <title>Cadastro de Contato</title>
</head>
<body>
    
    <form action="cadastroContato.php">
        <table>
            <tr>
                <td><label for="nome">Nome: </label></td>
                <td><input type="text" name="cadNome"></td>
            </tr>

            <tr>
                <td><label for="endereco">Endereco: </label></td>
                <td><input type="text" id="endereco" name="cadEndereco"></td>
            </tr>

            <tr>
                <td><label for="telefone">Telefone</label></td>
                <td><input type="number" id="telefone" name="telefone"></td>
            </tr>

            <tr>
                <td><label for="email">Email</label></td>
                <td><input type="email" id="email" name="email"></td>
            </tr>

            <tr>
                <td><label for="celular">Celular</label></td>
                <td><input type="number" id="celular" name="celular"></td>
            </tr>

            <button id="btnCadContato" type="submit" name="CadastraContato">Cadastrar</button>
        </table>
    </form>
</body>
</html>

<?php
    extract($_POST);

    if(isset($_POST["CadastrarContato"]))
    {
        echo "teste";
        include_once("connect.php");
        $obj = new connect();
        $resultado = $obj->conectarBanco();

        $sql = "INSERT INTO Agenda (Nome, endereco, telefone, email, celular) VALUES ('".$_POST["cadNome"]."', '".$_POST["cadEndereco"]."', '".$_POST["telefone"]."', '".$_POST["email"]."', '".$_POST["celular"]."');";
    }
?>